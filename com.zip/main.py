from telethon.sync import TelegramClient
from telethon.tl.functions.photos import UploadProfilePhotoRequest, DeletePhotosRequest
from telethon import TelegramClient, events
import time
api_id = 26930344
api_hash = '9718dcfcf3e56d1fc1c2bd0d3cc739ae'
name = "neol1tic"
client = TelegramClient(name, api_id, api_hash)
client.start()
@client.on(events.NewMessage(chats=('https://t.me/elizzi69')))
async def comment_on_new_post(event):
				sender_post = event.sender_id
				post_text = event.text
				@client.on(events.NewMessage(chats=('https://t.me/fukksleepchat')))
				async def comment(post):
					if post.sender_id == sender_post:
						if post.text == post_text:
							await post.reply("Ливай с позором")
client.run_until_disconnected()